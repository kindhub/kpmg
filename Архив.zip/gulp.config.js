const maxIndexHtmlSizeB = 400000;
const isPage = true;

module.exports = {
	maxIndexHtmlSizeB,
	isPage
}
